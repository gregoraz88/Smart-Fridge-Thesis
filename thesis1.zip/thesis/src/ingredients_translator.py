#from translate import Translator
from googletrans import Translator
import json

path = 'C:/Users/gregh/Desktop/thesis/barcode_data'
barcode_file_path = 'barcodes.json'
with open(path + '/' + barcode_file_path) as json_file:
    barcode_data = json.load(json_file)


for food_name in barcode_data.values():
    translator = Translator()
    translation = translator.translate(
    food_name,dest='en')
    print('Before------',food_name)
    print('After-------',translation.text)
