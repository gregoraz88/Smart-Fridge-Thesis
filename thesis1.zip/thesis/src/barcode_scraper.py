import requests
from bs4 import BeautifulSoup
import config
from os import getcwd,path,chdir
import json



counter = 0
page_url = 'https://world.openfoodfacts.org'
base_url = 'https://world.openfoodfacts.org/country/netherlands'
barcode_dict= {}
page_links = []



def save_barcodes(filename, barcode_dict):
    with open(filename, 'w') as f:
        json.dump(barcode_dict, f)

def retun_page_products(url):
    page = requests.get(url)
    web_tree =  BeautifulSoup(page.text, 'html.parser')
    page_links = move_to_next_page(web_tree)
    products = web_tree.find(class_='products')
    return products,page_links


def move_to_next_page(web_page):
    page_links = []
    pagination = web_page.find(class_= 'pagination')
    for link in pagination.find_all('a',href=True):
        if link['href'] :
            temp_link = page_url + link['href']
            page_links.append(temp_link)
    return page_links

def return_product_quantity(product_page):
    tree= BeautifulSoup(product_page.text,'html.parser')
    div = tree.find(class_='field')
    div = tree.find('div',class_="medium-12 large-8 xlarge-8 xxlarge-8 columns").find_all('p')
    temp_str = div[0].text.split(':')
    if temp_str[0] == 'Quantity':
        quantity = temp_str[1]
        return quantity
    else:
        return 'Null'

page_counter = 1
products,page_links = retun_page_products(base_url)
while ( counter < 339):
    for info in  products.find_all('a', href= True):
        if info.text:
            temp_info = info['href']
            print(temp_info)
            try:
                product_page = requests.get(page_url+temp_info)
            except requests.exceptions.RequestException as e:  # This is the correct syntax
                raise SystemExit(e)
            #product_page = requests.get(page_url+temp_info)
            temp_list = temp_info.split('/')
            if len(temp_list) > 3:
                barcode_dict[temp_list[2]] = tuple((temp_list[3],return_product_quantity(product_page)))
            else: continue
    page_counter += 1
    print('Done with pageeeeeeeeeeeeeeeee')
    print('moving to page',  base_url + '/'+ str(page_counter))
    next_url = base_url + '/'+ str(page_counter)
    products,page_links = retun_page_products(next_url)
    counter += 1
chdir('..')
chdir('barcode_data')
project_path = getcwd()
path1 = path.join(project_path, 'barcodes.json')
save_barcodes(path1,barcode_dict)


#print(barcode_dict)
#print(products_tag)
