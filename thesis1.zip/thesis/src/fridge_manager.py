import json

class fridge_contet:
    def __init__(self,name, content_list=None):
        self.name = name
        if content_list is None:
            content_list = {}
        self.content_list = content_list
    def add(self,fridge_el):
        if fridge_el.name in self.content_list:
            self.increment_freq(fridge_el)
        else:
            self.content_list[fridge_el.name] = 1
    def increment_freq(self,fridge_el):
        self.content_list[fridge_el.name] = self.content_list[fridge_el.name]+1
    def remove(self,fridge_el):
        if self.content_list[fridge_el.name] == 1:
            del self.content_list[fridge_el.name]
        else:
            self.decrement_freq(fridge_el)
    def decrement_freq(self, fridge_el):
        self.content_list[fridge_el.name] =  self.content_list[fridge_el.name]-1
    def __str__(self):
        return 'fridge elements at '+ str(self.name)+' ^s fridge are: '+ (','.join(str(element)for element in self.content_list.items()))

class fridge_el:
    ### based on the element added, include its nutritional values
    def __init__(self,name):
        self.name = name
        self.label = 'IN'
        self.freq = 1
        self.quantity =0
    def __str__(self):
        return str(self.name)


greg_fridge = fridge_contet('Greg')
#def : check for the existencde of 'barcode' --barcode from scanned element --mapping to a 'barcodes.json' -- json dictionary of barcodes and respective element
#- if the 'barcode' exists in dictionary - return a True, the value of the key of the barcode -- else return false and the barcode which does not exists in the
#dictionary
def check_and_return_barcode_existance(barcode):
    path = 'C:/Users/gregh/Desktop/thesis/barcode_data'
    barcode = barcode[2:len(barcode)-1]
    barcode_file_path = 'barcodes.json'
    with open(path + '/' + barcode_file_path) as json_file:
        barcode_data = json.load(json_file)
    if barcode in barcode_data:
        el = fridge_el(barcode_data[barcode])
        greg_fridge.add(el)
        print(greg_fridge)
        return tuple((True,barcode_data[barcode]))
    else:
        print('this is the input barcode which does not exists', barcode)
        return tuple((False,barcode))

print(greg_fridge)
